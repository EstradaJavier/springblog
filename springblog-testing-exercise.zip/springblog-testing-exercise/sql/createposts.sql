USE blog_db;
INSERT INTO posts(title, body) VALUES
('Test', 'Test post'),
('My Post', 'My post'),
('Beagles', 'Summer, Ducle and Obi'),
('Test', 'Test post'),
('My Post', 'My post'),
('Beagles', 'Summer, Ducle and Obi'),
('Test', 'Test post'),
('My Post', 'My post'),
('Beagles', 'Summer, Ducle and Obi'),
('Test', 'Test post'),
('My Post', 'My post'),
('Beagles', 'Summer, Ducle and Obi'),
('Test', 'Test post'),
('My Post', 'My post'),
('Beagles', 'Summer, Ducle and Obi')