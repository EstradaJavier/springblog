package com.example.springblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringblogApplicationTests {

    @Test
    void contextLoads() {
    }

}
